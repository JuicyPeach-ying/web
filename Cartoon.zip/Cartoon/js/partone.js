var partone0 = document.getElementById("partone0");
		var partone1 = document.getElementById("partone1");
		var partone2 = document.getElementById("partone2");
		var partone3 = document.getElementById("partone3");
		var partone4 = document.getElementById("partone4");
		var title = document.getElementById("title");
		var descripe = document.getElementById("describe");
		partone1.onmousemove = function(){
			partone0.src = "img/partone1.jpg"
			partone0.style.width = "526px";
			partone0.style.height = "306px";
			title.innerHTML = "两不疑";
			descripe.innerHTML = "结发为夫妻，恩爱两不疑。原本两看..."
		}
		partone2.onmousemove = function(){
			partone0.src = "img/partone2.jpg"
			partone0.style.width = "526px";
			partone0.style.height = "306px";
			title.innerHTML = "总裁想静静";
			descripe.innerHTML = "总静一直以为这个时间上没有她办不到..."
		}
		partone3.onmousemove = function(){
			partone0.src = "img/partone3.jpg"
			partone0.style.width = "526px";
			partone0.style.height = "306px";
			title.innerHTML = "三梳";
			descripe.innerHTML = "拥有千万粉丝的禁欲系国民男神傅延川..."
		}
		partone4.onmousemove = function(){
			partone0.src = "img/partone4.jpg"
			partone0.style.width = "526px";
			partone0.style.height = "306px";
			title.innerHTML = "虎王供养日记";
			descripe.innerHTML = "狐妖大王巡山捡到一只总是被欺负苦苦..."
		}
		